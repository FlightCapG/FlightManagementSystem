package com.cg.flight.app.dto;

import lombok.Data;
@Data
public class ExceptionDTOResponse {
private String errorMsg;
private String dateTime;
}
