package com.cg.flight.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FlightManagementSystem1Application {

	public static void main(String[] args) {
		SpringApplication.run(FlightManagementSystem1Application.class, args);
	}

}
